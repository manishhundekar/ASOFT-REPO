package com.airline;

public class International extends Airlines{
	
	private String zonalCode;
	private double ticketCost = 0;
	
	public International(String airId, String source, String destination, String zonalCode)
			throws InvalidEntryException {
		super(airId, source, destination);
		if(zonalCode.equals("I001") || zonalCode.equals("I002") || zonalCode.equals("I003"))
		{
			this.zonalCode = zonalCode;
		}
		else
		{
			throw new InvalidEntryException("Invalid Zonal Code");
		}
	}

	public String getZonalCode() {
		return zonalCode;
	}

	public void setZonalCode(String zonalCode) {
		this.zonalCode = zonalCode;
	}

	public double getTicketCost() {
		return ticketCost;
	}

	public void setTicketCost(double ticketCost) {
		this.ticketCost = ticketCost;
	}

	@Override
	public void bookTicket(int noOfTickets) {
	
		if(zonalCode.equalsIgnoreCase("I001"))
		{
			this.ticketCost += 25000.00 * noOfTickets;
		}
		else if(zonalCode.equalsIgnoreCase("I002"))
		{
			this.ticketCost += 36000.00 * noOfTickets;
		}
		else if(zonalCode.equalsIgnoreCase("I003"))
		{
			this.ticketCost += 38000.00 * noOfTickets;
		}
	}

	
	
	

}
